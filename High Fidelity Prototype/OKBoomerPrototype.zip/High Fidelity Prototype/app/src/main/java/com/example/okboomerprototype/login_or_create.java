package com.example.okboomerprototype;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class login_or_create extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
